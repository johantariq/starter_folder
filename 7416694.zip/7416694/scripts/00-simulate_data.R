#### Preamble ####
# Purpose: Simulates crime counts across various years
# Author: Johan Tariq
# Date: 23 January 2024
# Contact: johan.tariq@mail.utoronto.ca
# License: MIT
# Pre-requisites: none


#### Workspace setup ####
library(tidyverse)
library(ggplot2)
library(janitor)
library(reshape2)

#### Expectations ####
# Analyze crime counts in 2020, 2021, 2022, 2023

#### Simulate counts of every crime in each year ####
crime_type = c("Assault", "AutoTheft", "BreakEnter", "Homicide", "Robbery")
crime_count_2020 = c(15, 852, 750, 3, 570)
crime_count_2021 = c(988, 180, 772, 98, 332)
crime_count_2022 = c(88, 638, 934, 514, 931)
crime_count_2023 = c(476, 450, 432, 536, 168)

#### Simulate tibble ####
df =
  tibble(
    crime_type,
    "2020" = crime_count_2020,
    "2021" = crime_count_2021,
    "2022" = crime_count_2022,
    "2023" = crime_count_2023
)

#### Create summary statistics of crimes ####

#### Find total crimes per year ####
#### Find averages of crimes ####
df_1 = df %>% mutate(Average = rowMeans(select(.,starts_with("202")), na.rm = TRUE))
df_2 = df_1 %>%
  bind_rows(summarise(.,
                      across(where(is.numeric), sum),
                      across(where(is.character), ~"Total")))


#### Create graphs of simulated data ####

# Bar graph of crimes by type in each year
datalong <- gather(df, key="year", value="value", c("2020", "2021", "2022", "2023"))
ggplot(datalong,
       aes(x = crime_type,
           y = value))+
  geom_bar(stat='identity') +
  facet_wrap(~year,  ncol=1)
