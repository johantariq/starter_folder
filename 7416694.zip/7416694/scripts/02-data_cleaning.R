#### Preamble ####
# Purpose: Cleans the raw data
# Author: Johan Tariq
# Date: 23 January 2024
# Contact: johan.tariq@mail.utoronto.ca
# License: MIT
# Pre-requisites: none

#### Workspace setup ####
library(tidyverse)

#### Clean data ####
raw_data <- read_csv("inputs/data/raw_data.csv")
## This is the cleaned dataset that I'm going to analyze for this paper.
cleaned_data <- raw_data %>%
  select(contains(c("AREA")) |contains(c("2023"))) %>%
  select(contains(c("AREA")) |contains(c("POP")) |contains(c("RATE")))
## This is a brief, shortened dataset that I'm using for Figure 1.
summarized_data <- cleaned_data %>%
  select(c(1, 4, 5, 11))
## This is a brief, shortened dataset that I'm using for Figure 3.
summarized_data2 <- cleaned_data[order(cleaned_data$POPULATION_2023),] %>% 
                                      select(c(1, 2, 3, 5))
## This is a brief, shortened dataset that I'm using for Figure 2.
summarized_data3 <- cleaned_data[order(-cleaned_data$POPULATION_2023),] %>%
                                      select(c(1, 2, 3, 5))
  

#### Save data ####
write_csv(cleaned_data, "inputs/data/cleaned_data.csv")
write_csv(summarized_data, "inputs/data/summarized_data.csv")
write_csv(summarized_data2, "inputs/data/summarized_data2.csv")
write_csv(summarized_data3, "inputs/data/summarized_data3.csv")

