#### Preamble ####
# Purpose: Downloads and saves the data from OpenDataToronto
# Author: Johan Tariq
# Date: 23 January 2024
# Contact: johan.tariq@mail.utoronto.ca
# License: MIT
# Pre-requisites: none


#### Workspace setup ####
library(opendatatoronto)
library(tidyverse)
library(dplyr)
library(readr)

#### Download data ####
package <- show_package("neighbourhood-crime-rates")
resources <- list_package_resources("neighbourhood-crime-rates")

#### Save data ####
datastore_resources <- filter(resources, tolower(format) %in% c('csv', 'geojson'))
raw_data <- filter(datastore_resources, row_number()==1) %>% get_resource()

#### Write data ####
write_csv(
  x = raw_data,
  file = "raw_data.csv"
)

#### Read data ####
readr::read_csv("inputs/data/raw_data.csv")
